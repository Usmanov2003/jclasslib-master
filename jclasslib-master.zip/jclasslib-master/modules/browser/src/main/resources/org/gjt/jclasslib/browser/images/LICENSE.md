The icons in this directory are licensed by INCORS GmbH

https://www.iconexperience.com/
