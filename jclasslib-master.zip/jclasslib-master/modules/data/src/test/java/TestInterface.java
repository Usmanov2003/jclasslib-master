public interface TestInterface {
    void run(int[] data);
}
